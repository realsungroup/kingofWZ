export interface LoginInterface {
    account:string;
    passWord?:string;
}