import { BreadUrlDirective } from './bread-url.directive';

describe('BreadUrlDirective', () => {
  it('should create an instance', () => {
    const directive = new BreadUrlDirective();
    expect(directive).toBeTruthy();
  });
});
