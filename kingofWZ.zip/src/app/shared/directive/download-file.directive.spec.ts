import { DownloadFileDirective } from './download-file.directive';

describe('DownloadFileDirective', () => {
  it('should create an instance', () => {
    const directive = new DownloadFileDirective();
    expect(directive).toBeTruthy();
  });
});
