import { Directive,Input } from '@angular/core';

@Directive({
  selector: '[appDownloadFile]'
})
export class DownloadFileDirective {

  constructor() { }

}
