import { ExportXlsxDirective } from './export-xlsx.directive';

describe('ExportXlsxDirective', () => {
  it('should create an instance', () => {
    const directive = new ExportXlsxDirective();
    expect(directive).toBeTruthy();
  });
});
