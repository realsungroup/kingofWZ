import { FloatBuildPipe } from './float-build.pipe';

describe('FloatBuildPipe', () => {
  it('create an instance', () => {
    const pipe = new FloatBuildPipe();
    expect(pipe).toBeTruthy();
  });
});
