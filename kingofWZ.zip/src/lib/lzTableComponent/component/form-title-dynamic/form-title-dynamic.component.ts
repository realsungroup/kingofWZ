import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-form-title-dynamic',
  templateUrl: './form-title-dynamic.component.html',
  styleUrls: ['./form-title-dynamic.component.scss']
})
export class FormTitleDynamicComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
