export const ADD = 'added';
export const MODIF = 'modified';
export const REMOVE = 'removed';

